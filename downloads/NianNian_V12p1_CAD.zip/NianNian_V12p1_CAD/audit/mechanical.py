from pathlib import Path
import cadquery as cq,json,itertools
R=Path(__file__).resolve().parent.parent
names=['A_main_two_bay','C_rear_cover','E_battery_spacer','K_BOOT_cap','K_RST_cap','D_daisy_petals','D2_daisy_center','D3_stem_leaves']
o={k:cq.importers.importStep(str(R/'cad'/(k+'.step'))) for k in names}
r=[]
for a,b in itertools.combinations(names,2):
 v=o[a].val().intersect(o[b].val()).Volume();r.append(dict(pair=[a,b],overlap_mm3=round(v,6),pass_check=v<.01))
print('printable pairs',len(r),'failures',[x for x in r if not x['pass_check']],flush=True)
# Check a continuous insertion sweep for the reference cable jacket.
p=json.loads((R/'params.json').read_text());T=p['body_depth'];bx=p['board_x']
plug=cq.Workplane('XY').box(12,20,6,centered=(True,True,False)).translate((bx,-35.5,T-p['usb_center_z']-3))
for k in ['A_main_two_bay','C_rear_cover','K_BOOT_cap','K_RST_cap']:
 v=plug.val().intersect(o[k].val()).Volume();r.append(dict(pair=['reference_12x6_cable_sweep',k],overlap_mm3=round(v,6),pass_check=v<.01))
h=cq.importers.importStep(str(R/'cad/hardware_reference.step'))
b=h.val().BoundingBox();print('hardware envelope',b.xlen,b.ylen,b.zlen,flush=True)
# Vertical insertion is from the open rear. Canonical rear is -Z.
for dz in [0,-.25,-.5,-1,-2,-4,-8,-12]:
 v=h.translate((0,0,dz)).val().intersect(o['A_main_two_bay'].val()).Volume();r.append(dict(pair=['board_rear_insertion','body'],offset_z=dz,overlap_mm3=round(v,6),pass_check=v<.01))
(R/'audit/mechanical.json').write_text(json.dumps(r,indent=2)+'\n')
print('ALL failures',[x for x in r if not x['pass_check']],flush=True)
