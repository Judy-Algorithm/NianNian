from pathlib import Path
import subprocess,zipfile,xml.etree.ElementTree as ET,json,re,hashlib
R=Path(__file__).resolve().parent.parent
BIN='/tmp/niannian-bambu-mount/BambuStudio.app/Contents/MacOS/BambuStudio'
base=[BIN,'--datadir','/tmp/niannian-bambu-cli-data','--arrange','0','--orient','0','--slice','1']
first=R/'print/base.3mf'
cmd=base+['--curr-bed-type','Textured PEI Plate','--load-settings',str(R/'slicer-settings/machine.json')+';'+str(R/'slicer-settings/process.json'),'--load-filaments',str(R/'slicer-settings/filament.json'),'--export-3mf',str(first),str(R/'print/V12_蓝色全套5件_纯模型.3mf')]
with (R/'audit/slice-base.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
with zipfile.ZipFile(first) as z:c={n:z.read(n) for n in z.namelist()}
root=ET.fromstring(c['Metadata/model_settings.config']);plate=root.find('plate')
for mi in plate.findall('model_instance'):plate.remove(mi)
for j,ob in enumerate(root.findall('object')):
 name=next(m.attrib['value'] for m in ob.findall('metadata') if m.attrib.get('key')=='name')
 for k,v in [('enable_support','1' if name=='C_rear_cover' else '0')]+([('brim_type','outer_only'),('brim_width','3')] if name.startswith('K_') else []):ET.SubElement(ob,'metadata',key=k,value=v)
 mi=ET.SubElement(plate,'model_instance')
 for k,v in [('object_id',ob.attrib['id']),('instance_id','0'),('identify_id',str(8+j*4))]:ET.SubElement(mi,'metadata',key=k,value=v)
c['Metadata/model_settings.config']=ET.tostring(root,encoding='utf-8',xml_declaration=True)
p=R/'print/configured.3mf'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for k,v in c.items():z.writestr(k,v)
out=R/'print/V12p1_ready.3mf'
with (R/'audit/slice-final.log').open('w') as f:subprocess.run(base+['--export-3mf',str(out),str(p)],stdout=f,stderr=subprocess.STDOUT,check=True)
with zipfile.ZipFile(out) as z:
 c={n:z.read(n) for n in z.namelist()};g=c['Metadata/plate_1.gcode'].decode();cfg=json.loads(c['Metadata/project_settings.config']);root=ET.fromstring(c['Metadata/model_settings.config']);si=ET.fromstring(c['Metadata/slice_info.config'])
 assert len(root.findall('object'))==len(root.findall('plate/model_instance'))==5
 assert cfg['filament_type']==['PETG'] and cfg['printer_model']=='Bambu Lab X1 Carbon'
 assert hashlib.md5(c['Metadata/plate_1.gcode']).hexdigest()==c['Metadata/plate_1.gcode.md5'].decode().strip().lower()
 assert '; FEATURE: Support' in g and g.count('; FEATURE: Brim')>=2
 for m in si.findall('plate/metadata'):
  if m.attrib['key']=='printer_model_id':m.set('value','BL-P001')
 c['Metadata/slice_info.config']=ET.tostring(si,encoding='utf-8',xml_declaration=True)
 stats={m.attrib['key']:m.attrib['value'] for m in si.findall('plate/metadata')};stats['native_import_and_reslice_passed']=True
 (R/'audit/slicer.json').write_text(json.dumps(stats,indent=2)+'\n')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for k,v in c.items():z.writestr(k,v)
print('Native import/reslice verified',stats['prediction'],'seconds',stats['weight'],'g',flush=True)
