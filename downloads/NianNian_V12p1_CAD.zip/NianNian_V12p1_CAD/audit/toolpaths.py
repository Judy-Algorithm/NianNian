from pathlib import Path
from zipfile import ZipFile
from collections import Counter
import re,json
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent.parent
p=R/'print/V12p1_ready.3mf'
with ZipFile(p) as z:g=z.read('Metadata/plate_1.gcode').decode().splitlines()
x=y=zv=0.;obj=None;role='';layer=0;segments=[];counts=Counter();brims=Counter();supports=0
for ln in g:
 if ln=='; CHANGE_LAYER':
  layer+=1
  if layer>1:break
 if not layer:continue
 if ln.startswith('; OBJECT_ID:'):obj=int(ln.split(':')[1])
 if ln.startswith('; FEATURE:'):role=ln.split(':',1)[1].strip()
 if not re.match(r'^G[123] ',ln):continue
 d={k:float(v) for k,v in re.findall(r'([XYZE])(-?(?:\d*\.\d+|\d+))',ln)}
 nx=d.get('X',x);ny=d.get('Y',y);zv=d.get('Z',zv)
 if d.get('E',0)>0 and ('X'in d or 'Y'in d):
  assert 0<=min(x,nx) and max(x,nx)<=256 and 0<=min(y,ny) and max(y,ny)<=256
  assert not(min(x,nx)<18 and min(y,ny)<28),'exclusion zone'
  segments.append((x,y,nx,ny,role,obj));counts[obj]+=1
  if role=='Brim':brims[obj]+=1
  if role.startswith('Support'):supports+=1
 x,y=nx,ny
assert set(counts)=={8,12,16,20,24},counts
assert brims[20]>0 and brims[24]>0 and supports>0
out={'first_layer_objects':dict(counts),'cap_brim_segments':dict(brims),'support_segments':supports,'bed_and_exclusion_check':True,'note':'Toolpath audit, not a physical adhesion test; arcs shown as chords in overview.'}
(R/'audit/first-layer.json').write_text(json.dumps(out,indent=2)+'\n')
im=Image.new('RGB',(1100,1200),'white');dr=ImageDraw.Draw(im);f='/System/Library/Fonts/STHeiti Light.ttc'
def text(x,y,s,n=25):dr.text((x,y),s,font=ImageFont.truetype(f,n),fill='#253f4b')
text(35,22,'V12.1｜首层实际切片路径',35);text(35,82,'蓝：模型　橙：支撑　紫：小帽子附着边',24)
def pt(x,y):return (40+x*4,1160-y*4)
dr.rectangle((*pt(0,256),*pt(256,0)),outline='#b7c8ce',width=2)
a=pt(0,28);b=pt(18,0);dr.rectangle((a[0],a[1],b[0],b[1]),fill='#ececec')
for x,y,nx,ny,role,obj in segments:
 color='#f3943e' if role.startswith('Support') else '#a574c1' if role=='Brim' else '#4b94b6'
 dr.line([pt(x,y),pt(nx,ny)],fill=color,width=2)
im.save(R/'audit/首层路径检查.png');print(json.dumps(out),flush=True)
