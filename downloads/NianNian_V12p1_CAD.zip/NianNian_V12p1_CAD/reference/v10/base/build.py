from pathlib import Path
import cadquery as cq,json,math,struct,sys
reuse = "--reuse-step" in sys.argv
R=Path(__file__).parent;P=json.loads((R/'params.json').read_text());W=P['body_width'];H=P['body_height'];T=P['body_depth'];F=P['front_skin'];S=T-P['rear_skin'];bx=P['board_x'];by=P['board_y'];tx=P['battery_x'];ty=P['battery_y'];tz=P['tray_z'];top=tz+P['tray_depth'];C=P['fit_clearance']
def box(w,h,t,x=0,y=0,z=0,r=0):
 a=cq.Workplane('XY').box(w,h,t,centered=(True,True,False))
 if r:a=a.edges('|Z').fillet(r)
 return a.translate((x,y,z))
def cyl(d,h,x=0,y=0,z=0):return cq.Workplane('XY').circle(d/2).extrude(h).translate((x,y,z))
def drill(o,pts,d,z,h):
 for x,y in pts:o=o.cut(cyl(d,h,x,y,z))
 return o
fast=[(P['screw_x'],y) for y in [-P['screw_y'],P['screw_y']]]
outer=box(W,H,S,r=P['corner_radius'])
main=outer.faces('<Z').edges().chamfer(P['front_chamfer']).cut(box(W-2*P['wall'],H-2*P['wall'],S+1,z=F,r=P['corner_radius']-P['wall']))
main=main.cut(box(P['window_width'],P['window_height'],F+.4,bx,P['lcd_center_y'],z=-.2,r=P['window_corner_radius']))
for x,y in fast:main=main.union(cyl(2.8,S-F,x,y,F))
main=drill(main,fast,P['screw_pilot'],2.5,S)
# These four short guides locate the PCB perimeter without touching components or active glass.
for x in [bx-P['board_width']/2-C-.25,bx+P['board_width']/2+C+.25]:
 for y in [-12,12]:main=main.union(box(.5,5,5,x,y,F))
for y in [by-P['board_height']/2-C-.25,by+P['board_height']/2+C+.25]:
 for dx in [-11.7,11.7]:main=main.union(box(3,.5,5,bx+dx,y,F))
# Four battery-cartridge seats. The outer cover captures the cartridge, not the cell.
for x in [tx-13,tx+13]:
 for y in [-20,20]:main=main.union(box(4,4,tz-F,x,y,F))
# Local side stops remain below the lid, with 0.3 mm nominal clearance.
for y in [-P['tray_height']/2-C-.15,P['tray_height']/2+C+.15]:
 for x in [tx-10,tx+10]:main=main.union(box(5,.3,2,x,y,F))
# USB-C cable jacket clearance; the board's USB remains recessed behind the bottom edge.
def service_cuts(o):
 o=o.cut(box(P['usb_width'],8,P['usb_height'],bx,-H/2,z=P['usb_center_z']-P['usb_height']/2,r=.5))
 bootx=bx+P['boot_vendor_x'];rstx=bx+P['reset_vendor_x'];az=P['button_actuator_z']
 # BOOT: an intentional rear-edge notch, connected to the USB service opening.
 o=o.cut(box(P['boot_opening_width'],P['boot_opening_depth'],T+.5-P['boot_opening_floor'],bootx,-H/2,z=P['boot_opening_floor'],r=.6))
 # RST: coaxial pinhole and a small lead-in, not a second finger notch.
 tool=cq.Workplane('XZ').circle(P['reset_hole_diameter']/2).extrude(7,both=True).translate((rstx,-H/2,az))
 mouth=cq.Workplane('XY').newObject([cq.Solid.makeCone(P['reset_mouth_diameter']/2,P['reset_hole_diameter']/2,P['reset_mouth_depth'],cq.Vector(rstx,-H/2-.01,az),cq.Vector(0,1,0))])
 return o.cut(tool).cut(mouth)
main=service_cuts(main)
# Separate complete battery cartridge, with two screw ears entirely outside the pouch cavity.
tray=box(P['tray_width'],P['tray_height'],P['tray_depth'],tx,ty,tz,r=1.5).cut(box(P['tray_width']-2*P['tray_wall'],P['tray_height']-2*P['tray_wall'],P['tray_depth']+1,tx,ty,tz+P['tray_floor'],r=.5))
cap=box(P['tray_width'],P['tray_height'],P['battery_lid'],tx,ty,top,r=1.5)
ears=[(P['battery_ear_x'],y) for y in [-P['battery_ear_y'],P['battery_ear_y']]]
for x,y in ears:
 tray=tray.union(box(3.4,4,P['tray_depth'],x+.15,y,tz,r=.5))
 cap=cap.union(box(3.4,4,P['battery_lid'],x+.15,y,top,r=.5))
tray=drill(tray,ears,P['screw_pilot'],tz+2.5,P['tray_depth']);cap=drill(cap,ears,P['screw_clearance'],top-.1,2)
# Wide, open-top wire route; no connector or wire is pinched between mating flat faces.
tray=tray.cut(box(5,7,3,tx-P['tray_width']/2,0,z=top-2.9,r=.5))
cap=cap.cut(box(5,7,2,tx-P['tray_width']/2,0,z=top-.1,r=.5))
# Rear cover nests on the perimeter; bottom notch leaves the USB and maintenance access clear.
rear=box(W,H,P['rear_skin'],z=S,r=P['corner_radius'])
lip=box(W-2*P['wall']-.6,H-2*P['wall']-.6,.7,z=S-.7,r=1.5).cut(box(W-2*P['wall']-2.2,H-2*P['wall']-2.2,1,z=S-.8,r=.7))
rear=service_cuts(rear.union(lip));rear=drill(rear,fast,P['screw_clearance'],S-.8,3)
for y in [-18,18]:rear=rear.union(box(8,4,.6,tx,y,S-.6))
# Removable retainer floats 0.2 mm clear of the four copper standoffs, for optional soft pads.
retainer=box(P['retainer_ring_width'],P['retainer_ring_height'],P['retainer_skin'],bx,by,S-P['retainer_skin']).cut(box(P['retainer_cut_width'],P['retainer_cut_height'],2,bx,by,S-1))
contact=P['module_front_z']+P['copper_rear_offset']+P['retainer_contact_gap']
for dx in [-P['board_hole_dx'],P['board_hole_dx']]:
 for dy in [-P['board_hole_dy'],P['board_hole_dy']]:retainer=retainer.union(cyl(3,S-P['retainer_skin']-contact,bx+dx,by+dy,contact))
# Ordinary ten-petal daisy, separate white and yellow print pieces, no hanging feature.
def flower(extra,h,z):
 o=cyl(8.8+extra*2,h,tx,ty,z)
 for i in range(P['daisy_petals']):
  a=2*math.pi*i/P['daisy_petals']
  pet=cq.Workplane('XY').ellipse(P['daisy_petal_long']+extra,P['daisy_petal_short']+extra).extrude(h).rotate((0,0,0),(0,0,1),360*i/P['daisy_petals']).translate((tx+P['daisy_radius']*math.cos(a),ty+P['daisy_radius']*math.sin(a),z));o=o.union(pet)
 return o
fz=-P['inlay_projection'];petals=flower(0,P['inlay_thickness'],fz).cut(cyl(6.4,1,tx,ty,fz-.1));centre=cyl(6,P['inlay_thickness'],tx,ty,fz)
main=main.cut(flower(P['pocket_clearance'],.25,-.05))
main=main.cut(box(.35,45,.14,x=0,y=0,z=-.02,r=.12))
# Hardware geometry: manufacturer PCB/LCD/connector model. Only two header-pin solids are cropped.
source=R/'reference/vendor.step'
vendor=cq.importers.importStep(str(source));solids=vendor.solids().vals();keep=[]
# The plastic header extends to -6.1; metal pins below that are removed. Other taller components are retained.
clip=box(100,100,50,z=-6.1)
for i,s in enumerate(solids):
 if i in [309,310]:s=s.intersect(clip.val())
 keep.append(s)
module=cq.Workplane('XY').newObject([cq.Compound.makeCompound(keep)]).rotate((0,0,0),(0,1,0),180).translate((bx,1.7,P['module_front_z']+2.1))
cellz=tz+P['tray_floor']+P['cell_pad'];cell=box(P['battery_width'],P['battery_height'],P['battery_thickness'],tx,ty,cellz,r=.6)
# SD stays within the PCB outline in the supplied photo; keep a 1 mm placeholder above its socket.
sd=box(11,15,1,bx+.35,16.0,7.4,r=.3)
# Zero-force wire clearance sweep, illustrative only, not a printed or electrical component.
wire=box(4,6,1.4,x=.2,y=0,z=8.2,r=.5)
# Separate coupons reproduce the entire screen bezel and cartridge dimensions.
gauge=main.intersect(box(W/2-.3, H+1,T+1,x=-W/4-.15,z=-.1))
# Crop at x=0 to avoid leaving screw posts in the bezel coupon.
# Keep the complete screen rim; the boundary clips the central screw columns only.
batgauge=box(P['tray_width'],P['tray_height'],3,r=1).cut(box(P['tray_width']-2*P['tray_wall'],P['tray_height']-2*P['tray_wall'],4,z=-.1,r=.5))
parts=[]
def add(k,o,c,pr=True,flip=False,g='shell',ex=0):
 assert o.val().isValid(),k
 if pr:assert len(o.solids().vals())==1,(k,'disconnected',len(o.solids().vals()))
 parts.append(dict(key=k,label=k,obj=o,color=c,printable=pr,flip=flip,group=g,explode=ex))
add('A_main',main,'#79b4d9',ex=-20);add('A2_board_retainer',retainer,'#b7d5e9',flip=True,ex=18)
add('B_battery_box',tray,'#a5c8e2',ex=4);add('B2_battery_lid',cap,'#bad7eb',ex=12);add('C_blank_rear',rear,'#79b4d9',flip=True,ex=30)
add('D_daisy_petals',petals,'#fffdf4',g='decoration',ex=-28);add('D2_daisy_center',centre,'#ebc54b',g='decoration',ex=-28)
add('T_module_fit',gauge,'#79b4d9',g='coupon');add('T_battery_fit',batgauge,'#b7d5e9',g='coupon')
add('module_vendor_pins_trimmed',module,'#324d60',False,g='electronics',ex=-5);add('battery_package',cell,'#d6c78c',False,g='battery',ex=6);add('sd_placeholder',sd,'#8e3640',False,g='electronics',ex=-5)
selected=[p for p in parts if p['group']!='coupon'];checks=[]
for i,a in enumerate(selected):
 for b in selected[i+1:]:
  # Vendor solids overlap in places; test each printable part against the full compound, not hardware self-overlap.
  if not a['printable'] and not b['printable']:continue
  v=a['obj'].val().intersect(b['obj'].val()).Volume();checks.append(dict(pair=a['key']+'/'+b['key'],volume=round(v,6),pass_check=v<.01))
(R/'interference-checks.json').write_text(json.dumps(checks,indent=2))
print('Interference checks ready',flush=True)
assert all(x['pass_check'] for x in checks), 'collisions must be resolved before export'
assy=cq.Assembly(name='ShakeCard_V6_Compact_NO_LANYARD');mesh=[]
for p in parts:
 k=p['key'];o=p['obj']
 if not reuse or not (R/'cad'/(k+'.step')).exists():cq.exporters.export(o,str(R/'cad'/(k+'.step')))
 if p['printable']:
  po=o.rotate((0,0,0),(1,0,0),180) if p['flip'] else o;po=po.translate((0,0,-po.val().BoundingBox().zmin));out=R/'print'/(k+'.stl');cq.exporters.export(po,str(out),tolerance=.03,angularTolerance=.1)
  raw=bytearray(out.read_bytes());n=struct.unpack_from('<I',raw,80)[0];zs=[84+i*50+20+j*12 for i in range(n) for j in range(3)];lo=min(struct.unpack_from('<f',raw,j)[0] for j in zs)
  for j in zs:struct.pack_into('<f',raw,j,struct.unpack_from('<f',raw,j)[0]-lo)
  out.write_bytes(raw)
 if p not in selected:continue
 assy.add(o,name=k,color=cq.Color(*[int(p['color'][i:i+2],16)/255 for i in [1,3,5]]));v,f=o.val().tessellate(.15,.25);mesh.append({k:p[k] for k in ['key','label','color','group','explode']}|dict(v=[[q.x,q.y,q.z] for q in v],f=[list(q) for q in f]))
(R/'mesh-data.json').write_text(json.dumps(mesh,separators=(',',':')))
print('Meshes ready',flush=True)
if not reuse or not (R/'cad/ShakeCard_compact_assembly.step').exists():assy.export(str(R/'cad/ShakeCard_compact_assembly.step'))
section=[];clip=box(W+10,100,T+10,y=50,z=-1)
for p in selected:
 if p['group']=='electronics':continue
 o=p['obj'].cut(clip)
 if o.val().Volume()>0:
  v,f=o.val().tessellate(.15,.25);section.append(dict(key=p['key'],color=p['color'],group=p['group'],explode=0,v=[[q.x,q.y,q.z] for q in v],f=[list(q) for q in f]))
(R/'mesh-data.json').write_text(json.dumps(mesh,separators=(',',':')));(R/'section-mesh.json').write_text(json.dumps(section,separators=(',',':')))
report=dict(body_mm=[W,H,T],max_depth_mm=T+P['inlay_projection'],screen_opening_mm=[P['window_width'],P['window_height']],hardware_module_bbox_mm=[round(getattr(module.val().BoundingBox(),k),3) for k in ['xlen','ylen','zlen']],no_lanyard_features=True,checks=checks,physical_fit='not tested; battery dimensions, protruding metal, plug and wire bend need physical confirmation',battery_cavity_mm=[P['tray_width']-2*P['tray_wall'],P['tray_height']-2*P['tray_wall'],P['tray_depth']-P['tray_floor']])
(R/'checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert all(x['pass_check'] for x in checks),'collisions must be resolved'
