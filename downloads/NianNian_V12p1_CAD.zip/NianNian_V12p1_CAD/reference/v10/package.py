"""Create generic, printer-neutral 3MF build plates and a checked print handoff ZIP."""
from pathlib import Path
import struct,json,zipfile,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
NS='http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
ET.register_namespace('',NS)

def el(tag,**attrs): return ET.Element('{'+NS+'}'+tag,{k:str(v) for k,v in attrs.items()})

def plate(filename,part_names):
    model=el('model',unit='millimeter',**{'xml:lang':'zh-CN'})
    metadata=el('metadata',name='Title');metadata.text='念念 · 通用打印排版';model.append(metadata)
    resources=el('resources');model.append(resources);build=el('build');model.append(build)
    offset_x=10
    for index,name in enumerate(part_names,1):
        raw=(ROOT/'print'/name).read_bytes();count=struct.unpack_from('<I',raw,80)[0]
        lookup={};vertices=[];faces=[]
        for n in range(count):
            values=struct.unpack_from('<12fH',raw,84+50*n)
            face=[]
            for j in range(3):
                xyz=tuple(round(x,5) for x in values[3+j*3:6+j*3])
                if xyz not in lookup: lookup[xyz]=len(vertices);vertices.append(xyz)
                face.append(lookup[xyz])
            faces.append(face)
        lo=[min(v[i] for v in vertices) for i in range(3)];hi=[max(v[i] for v in vertices) for i in range(3)]
        obj=el('object',id=index,type='model',name=name.removesuffix('.stl'))
        mesh=el('mesh');vs=el('vertices');ts=el('triangles')
        for v in vertices:vs.append(el('vertex',x=v[0],y=v[1],z=v[2]))
        for f in faces:ts.append(el('triangle',v1=f[0],v2=f[1],v3=f[2]))
        mesh.extend([vs,ts]);obj.append(mesh);resources.append(obj)
        build.append(el('item',objectid=index,transform=f'1 0 0 0 1 0 0 0 1 {offset_x-lo[0]} {10-lo[1]} {-lo[2]}'))
        offset_x+=hi[0]-lo[0]+12
    types='<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>'
    rels='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'
    with zipfile.ZipFile(ROOT/'print'/filename,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml',types)
        archive.writestr('_rels/.rels',rels)
        archive.writestr('3D/3dmodel.model',ET.tostring(model,encoding='utf-8',xml_declaration=True))





plate('00_屏框_电池_背面挂耳试装.3mf',['T_module_fit.stl','T_battery_fit.stl','T_rear_loop_fit.stl'])
plate('01_前壳与电池盒_蓝色.3mf',['A_main.stl','B_battery_box.stl'])
plate('02_背面挂耳后盖与压框_蓝色.3mf',['C_pig_rear_hidden_loop.stl','A2_board_retainer.stl'])
plate('03_电池盖_蓝色.3mf',['B2_battery_lid.stl'])
plate('04_立体花瓣_白色.3mf',['D_daisy_petals.stl'])
plate('05_立体花心_黄色.3mf',['D2_daisy_center.stl'])
plate('06_花梗叶片_深绿或黑色.3mf',['D3_stem_leaves.stl'])

plate('07_只打圆孔挂耳试片.3mf',['T_rear_loop_fit.stl'])

plate('08_先打USB与按键试装.3mf',['T_access_main.stl','T_access_rear.stl'])
