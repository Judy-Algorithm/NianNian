"""Render the exported CAD tessellation. All pictured geometry comes from build_case.py."""
from pathlib import Path
import math,json
import numpy as np
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
parts=[]
im=Image.new('RGB',(2400,1850),'#f6f4f1');draw=ImageDraw.Draw(im)
FONT='/System/Library/Fonts/STHeiti Light.ttc'
def text(x,y,s,size=24,color='#343d36'):
    draw.text((x,y),s,font=ImageFont.truetype(FONT,size),fill=color)
def panel(x0,y0,x1,y1):draw.rounded_rectangle((x0,y0,x1,y1),radius=20,fill='#ffffff',outline='#e6e1e9',width=2)
def render(rect,keys,yaw=0,pitch=0,explode=0):
    x0,y0,x1,y1=rect;cy,sy=math.cos(yaw),math.sin(yaw);cp,sp=math.cos(pitch),math.sin(pitch)
    matrix=np.array([[cy,0,sy],[sp*sy,cp,-sp*cy],[-cp*sy,sp,cp*cy]])
    transformed=[]
    for p in parts:
        if keys is not None and p['key'] not in keys:continue
        v=np.array(p['v']);v[:,2]=12.0-v[:,2];v[:,2]+=explode*p['explode']-12.0
        v=v@matrix.T;transformed.append((p,v))
    allv=np.vstack([v for _,v in transformed]);lo=allv[:,:2].min(axis=0);hi=allv[:,:2].max(axis=0)
    center=(lo+hi)/2;scale=min((x1-x0-22)/(hi[0]-lo[0]),(y1-y0-22)/(hi[1]-lo[1]))
    # Per-pixel depth testing: large CAD face triangles must not paint over a nearer bezel.
    width,height=x1-x0,y1-y0
    pixels=np.full((height,width,3),255,dtype=np.uint8)
    depth=np.full((height,width),np.inf)
    for p,v in transformed:
        rgb=np.array([int(p['color'][i:i+2],16) for i in [1,3,5]])
        screen=np.empty_like(v)
        screen[:,0]=width/2+(v[:,0]-center[0])*scale
        screen[:,1]=height/2-(v[:,1]-center[1])*scale
        screen[:,2]=v[:,2]
        for ids in p['f']:
            a,b,c=screen[ids]
            xmin=max(0,int(math.floor(min(a[0],b[0],c[0]))));xmax=min(width-1,int(math.ceil(max(a[0],b[0],c[0]))))
            ymin=max(0,int(math.floor(min(a[1],b[1],c[1]))));ymax=min(height-1,int(math.ceil(max(a[1],b[1],c[1]))))
            if xmin>xmax or ymin>ymax:continue
            denominator=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
            if abs(denominator)<1e-8:continue
            yy,xx=np.mgrid[ymin:ymax+1,xmin:xmax+1];xx=xx+.5;yy=yy+.5
            wa=((b[1]-c[1])*(xx-c[0])+(c[0]-b[0])*(yy-c[1]))/denominator
            wb=((c[1]-a[1])*(xx-c[0])+(a[0]-c[0])*(yy-c[1]))/denominator
            wc=1-wa-wb
            z=wa*a[2]+wb*b[2]+wc*c[2]
            area=depth[ymin:ymax+1,xmin:xmax+1]
            mask=(wa>=-1e-7)&(wb>=-1e-7)&(wc>=-1e-7)&(z<area)
            if not mask.any():continue
            original=v[ids];normal=np.cross(original[1]-original[0],original[2]-original[0]);norm=np.linalg.norm(normal) or 1
            shade=.73+.25*abs(np.dot(normal,[-.3,.35,-.8])/norm)
            pixels[ymin:ymax+1,xmin:xmax+1][mask]=np.clip(rgb*shade,0,255).astype(np.uint8)
            area[mask]=z[mask]
    # Technical edge emphasis from the actual depth buffer makes same-color relief legible.
    edge=np.zeros_like(depth,dtype=bool)
    with np.errstate(invalid='ignore'):
        dx=(np.abs(depth[:,1:]-depth[:,:-1])>.18)&np.isfinite(depth[:,1:])&np.isfinite(depth[:,:-1])
        dy=(np.abs(depth[1:,:]-depth[:-1,:])>.18)&np.isfinite(depth[1:,:])&np.isfinite(depth[:-1,:])
    edge[:,1:]|=dx;edge[1:,:]|=dy
    pixels[edge]=np.clip(pixels[edge]*.68,0,255).astype(np.uint8)
    im.paste(Image.fromarray(pixels),(x0,y0))




